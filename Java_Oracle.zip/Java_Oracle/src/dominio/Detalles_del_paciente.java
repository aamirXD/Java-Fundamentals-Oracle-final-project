package dominio;
import java.awt.Color;
import java.sql.*;
import java.sql.Timestamp;
import javax.swing.JOptionPane;
public class Detalles_del_paciente extends javax.swing.JFrame
{
    int idUsuario, idPaciente;
    public Detalles_del_paciente(int idUsuario, int idPaciente) 
    {
        initComponents();
        this.idUsuario = idUsuario;
        this.idPaciente = idPaciente;
    }
    private void DetallesDelPaciente()
    {
        //Declaración de variables
        String fecha = txtfecha.getText().trim(); //fecha en texto
        Timestamp timestamp = Timestamp.valueOf(fecha); //trasnformación a timestamp
        String motivo = txtmotivo.getText().trim();
        String observacion = txtobservacion.getText().trim();
        
        
        //Proceso del SQL
        String sql = "Insert into consultas(id_paciente, id_usuario, fecha,motivo,observaciones) values(?,?,?,?,?)";
        
        try
        (
            Connection conexion = Conexion.conectar();
            PreparedStatement pst= conexion.prepareCall(sql);
        )
        {
            //insertando valores
            pst.setInt(1,idPaciente);
            pst.setInt(2,idUsuario);
            pst.setTimestamp(3,timestamp);
            pst.setString(4,motivo);
            pst.setString(5,observacion);
            
            int FilasAfectadas = pst.executeUpdate(); //verificando
            if (FilasAfectadas > 0)
            {
                JOptionPane.showMessageDialog(null,"Paciente registrado con éxito.");
                new Frmlogin().setVisible(true);
                this.dispose();
            }
            else
            {
                JOptionPane.showMessageDialog(null,"Error al registrar Paciente.");
            }
        }
        catch (SQLException e)
        {
            JOptionPane.showMessageDialog(this,"Error al conectar con la base de datos"+e.getMessage());
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtfecha = new javax.swing.JTextField();
        txtmotivo = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtobservacion = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        btnguardar = new javax.swing.JButton();
        btnlimpiar = new javax.swing.JButton();
        btnsalir = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel2.setText("Fecha de creación");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 140, -1, -1));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setText("Información de la consulta");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 110, 244, -1));

        txtfecha.setToolTipText("");
        txtfecha.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtfechaFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtfechaFocusLost(evt);
            }
        });
        jPanel2.add(txtfecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 170, 244, -1));

        txtmotivo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtmotivoActionPerformed(evt);
            }
        });
        jPanel2.add(txtmotivo, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 230, 521, 150));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel4.setText("Observaciones");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 380, -1, -1));
        jPanel2.add(txtobservacion, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 410, 521, 130));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel5.setText("Motivo");
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 200, -1, -1));

        btnguardar.setBackground(new java.awt.Color(0, 102, 255));
        btnguardar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnguardar.setForeground(new java.awt.Color(255, 255, 255));
        btnguardar.setText("Guardar");
        btnguardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnguardarActionPerformed(evt);
            }
        });
        jPanel2.add(btnguardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 550, 153, 78));

        btnlimpiar.setBackground(new java.awt.Color(0, 102, 255));
        btnlimpiar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnlimpiar.setForeground(new java.awt.Color(255, 255, 255));
        btnlimpiar.setText("Limpiar");
        btnlimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnlimpiarActionPerformed(evt);
            }
        });
        jPanel2.add(btnlimpiar, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 550, 153, 78));

        btnsalir.setBackground(new java.awt.Color(0, 102, 255));
        btnsalir.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnsalir.setForeground(new java.awt.Color(255, 255, 255));
        btnsalir.setText("Salir");
        btnsalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsalirActionPerformed(evt);
            }
        });
        jPanel2.add(btnsalir, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 550, 153, 78));

        jPanel1.setBackground(new java.awt.Color(0, 102, 255));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Detalles del paciente");

        jPanel3.setBackground(new java.awt.Color(0, 91, 229));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(147, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(59, 59, 59)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 540, 100));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 635, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtmotivoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtmotivoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtmotivoActionPerformed

    private void txtfechaFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtfechaFocusLost
        // Cuando saca el mouse de la casilla:
        if (txtfecha.getText().isEmpty()) 
        {
            txtfecha.setText("YYYY-MM-DD hh:mm:ss");
            txtfecha.setForeground(Color.gray);
        }
    }//GEN-LAST:event_txtfechaFocusLost

    private void txtfechaFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtfechaFocusGained
        // cuando hace click en la casilla:
        if (txtfecha.getText().equals("YYYY-MM-DD hh:mm:ss")) 
        {
            txtfecha.setText("");
            txtfecha.setForeground(Color.black);
        }
    }//GEN-LAST:event_txtfechaFocusGained

    private void btnguardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnguardarActionPerformed
        // Botón guardar:
        DetallesDelPaciente();
    }//GEN-LAST:event_btnguardarActionPerformed

    private void btnlimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnlimpiarActionPerformed
        // Limpiar:
        txtfecha.setText("YYYY-MM-DD hh:mm:ss");
        txtfecha.setForeground(Color.gray);
        txtmotivo.setText("");
        txtobservacion.setText("");
    }//GEN-LAST:event_btnlimpiarActionPerformed

    private void btnsalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsalirActionPerformed
        // Salir:
        new Frmlogin().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnsalirActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Detalles_del_paciente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Detalles_del_paciente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Detalles_del_paciente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Detalles_del_paciente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                int idUsuario = 0; //se crea la variable idUsuario para evitar crear la instancia Detalles_del_paciente sin el valor de idUsuario
                int idPaciente = 0;
                new Detalles_del_paciente(idUsuario,idPaciente).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnguardar;
    private javax.swing.JButton btnlimpiar;
    private javax.swing.JButton btnsalir;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JTextField txtfecha;
    private javax.swing.JTextField txtmotivo;
    private javax.swing.JTextField txtobservacion;
    // End of variables declaration//GEN-END:variables
}
