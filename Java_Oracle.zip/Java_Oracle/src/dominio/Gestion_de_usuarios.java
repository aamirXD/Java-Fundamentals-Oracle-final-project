package dominio;
import com.mysql.cj.x.protobuf.MysqlxPrepare;
import java.sql.*;
import javax.swing.JOptionPane;
public class Gestion_de_usuarios extends javax.swing.JFrame 
{
    public Gestion_de_usuarios() 
    {
        initComponents(); //ejecuta los elementos gráficos
        ConsultaDePaciente(); //ejecuta ni bien inicia el programa el método ConsultaDePaciente()
        cbxusuarios.addActionListener(e -> MostrarDatos()); //actualiza los valores seleccionados del combo box
        cbxusuarios.addActionListener(e -> Consultas());
    }
    private void ConsultaDePaciente()
    {
        String sql = "Select id_usuario, nombre, rol from usuarios";
        try
        (
        Connection conexion = Conexion.conectar();
        PreparedStatement pst = conexion.prepareStatement(sql);
        ResultSet rs = pst.executeQuery()
        )
        {
            while (rs.next()) 
            {
            String idUsuario = rs.getString("id_usuario");
            cbxusuarios.addItem(idUsuario);
            }
        }
        catch (SQLException e)
        {
            JOptionPane.showMessageDialog(this,"Error al conectar con la base de datos: "+e.getMessage());
        }  
    }
    
    private void MostrarDatos()
    {
        String idSeleccionado = (String) cbxusuarios.getSelectedItem();
        if (idSeleccionado == null) return;
        {
        String sql = "Select nombre, rol from usuarios where id_usuario = ?";
        try
        (
        Connection conexion = Conexion.conectar();
        PreparedStatement pst = conexion.prepareStatement(sql);
        )
        {
            pst.setString(1, idSeleccionado);
            ResultSet rs = pst.executeQuery();
            
            if (rs.next()) 
            {
                txtnombre.setText(rs.getString("nombre"));
                txtrol.setText(rs.getString("rol"));
            }
        }
        catch (SQLException e)
        {
            JOptionPane.showMessageDialog(this,"Error al conectar con la base de datos: "+e.getMessage());
        }  
        }
    }
    
    private void Consultas()
    {
        String idSeleccionado = (String) cbxusuarios.getSelectedItem();
        String sql = "SELECT COUNT(*) AS cantidad FROM consultas WHERE id_usuario = ?";
        
        try
        (
                Connection conexion = Conexion.conectar();
                PreparedStatement pst = conexion.prepareStatement(sql)
        )
        {
            pst.setInt(1, Integer.parseInt(idSeleccionado)); // Filtrar por el ID del usuario
            ResultSet rs = pst.executeQuery();
            if (rs.next()) 
            {
                int cantidad = rs.getInt("cantidad"); // Obtener la cantidad de coincidencias
                if (cantidad != 0)
                {
                    txtconsultas.setText(""+cantidad);
                }
                else
                {
                    txtconsultas.setText("0");
                }
            }
        }
        catch (SQLException e)
        {
            JOptionPane.showMessageDialog(this,"Error al conectar con la tabla pacientes: "+e.getMessage());
        }
    }
    
    private void ModificarDatos()
    {
        String idSeleccionado = (String) cbxusuarios.getSelectedItem();
        String nombre = txtnombre.getText().trim();
        String rol = "";
        if (txtrol.getText().trim().equals("Administrador") || txtrol.getText().trim().equals("ARecepcionista") || txtrol.getText().trim().equals("Doctor") || txtrol.getText().trim().equals("Enfermero"))
        {
            rol = txtrol.getText().trim();
        }
        else
        {
            JOptionPane.showMessageDialog(this,"Rol ingresado no válido");
        }
        String sql = "Update usuarios Set nombre = ?, rol = ? where id_usuario = ?";
        try
        (
                Connection conexion = Conexion.conectar();
                PreparedStatement pst = conexion.prepareStatement(sql);
        )
        {
            if (!rol.isEmpty() && !nombre.isEmpty())
            {           
                pst.setString(1,nombre);
                pst.setString(2,rol);
                pst.setInt(3, Integer.parseInt(idSeleccionado));
                int filasAfectadas = pst.executeUpdate();
                if (filasAfectadas > 0)
                {
                    JOptionPane.showMessageDialog(this,"Datos del usuario modificado correctamente");
                }
            }
            else
            {
                JOptionPane.showMessageDialog(this,"Error al modificar los datos del usuario");
            }            
        }
        catch (SQLException e)
        {
            JOptionPane.showMessageDialog(this,"Error al modificar los datos: "+e.getMessage());
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        cbxusuarios = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtnombre = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtrol = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        txtconsultas = new javax.swing.JTextField();
        btnsalir = new javax.swing.JButton();
        btnmodificar = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        cbxusuarios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbxusuariosActionPerformed(evt);
            }
        });
        jPanel2.add(cbxusuarios, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 170, 156, -1));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel1.setText("ID de usuarios registrados");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 140, -1, -1));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setText("Lista de ID de usuarios");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 110, -1, -1));
        jPanel2.add(txtnombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 260, 156, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel4.setText("Información del usuario");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 200, -1, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel5.setText("Nombre");
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 230, -1, -1));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel6.setText("Rol");
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 290, -1, -1));
        jPanel2.add(txtrol, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 320, 156, -1));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel7.setText("Consultas hechas");
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 350, -1, -1));

        txtconsultas.setEnabled(false);
        jPanel2.add(txtconsultas, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 380, 156, -1));

        btnsalir.setBackground(new java.awt.Color(0, 102, 255));
        btnsalir.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnsalir.setForeground(new java.awt.Color(255, 255, 255));
        btnsalir.setText("Salir");
        btnsalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsalirActionPerformed(evt);
            }
        });
        jPanel2.add(btnsalir, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 420, 190, -1));

        btnmodificar.setBackground(new java.awt.Color(0, 102, 255));
        btnmodificar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnmodificar.setForeground(new java.awt.Color(255, 255, 255));
        btnmodificar.setText("Modificar");
        btnmodificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnmodificarActionPerformed(evt);
            }
        });
        jPanel2.add(btnmodificar, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 420, 190, -1));

        jPanel1.setBackground(new java.awt.Color(0, 102, 255));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("GESTIÓN DE USUARIOS");

        jPanel3.setBackground(new java.awt.Color(0, 91, 229));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 75, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(71, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addGap(33, 33, 33))
        );

        jPanel2.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 420, 100));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 462, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cbxusuariosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbxusuariosActionPerformed
        // combo box
    }//GEN-LAST:event_cbxusuariosActionPerformed

    private void btnsalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsalirActionPerformed
        // Salir:
        new Frmlogin().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnsalirActionPerformed

    private void btnmodificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnmodificarActionPerformed
        // Modificar:
        ModificarDatos();
    }//GEN-LAST:event_btnmodificarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Gestion_de_usuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Gestion_de_usuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Gestion_de_usuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Gestion_de_usuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Gestion_de_usuarios().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnmodificar;
    private javax.swing.JButton btnsalir;
    private javax.swing.JComboBox<String> cbxusuarios;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JTextField txtconsultas;
    private javax.swing.JTextField txtnombre;
    private javax.swing.JTextField txtrol;
    // End of variables declaration//GEN-END:variables
}
