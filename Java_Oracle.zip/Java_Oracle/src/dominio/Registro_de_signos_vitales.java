package dominio;
import java.sql.*;
import javax.swing.JOptionPane;

public class Registro_de_signos_vitales extends javax.swing.JFrame 
{
    public Registro_de_signos_vitales() //constructor
    {
        initComponents();
        IdPacientes();
    }
    private void IdPacientes() //método
    {
        String sql = "Select id_paciente, nombre, apellido from pacientes";
        try
            (
                Connection conexion = Conexion.conectar();
                PreparedStatement pst = conexion.prepareStatement(sql);
                ResultSet rs = pst.executeQuery()
            )
        {
            while (rs.next())
            {
                String idPaciente = rs.getString("id_paciente");
                String nombre = rs.getString("nombre");
                String apellido = rs.getString("apellido");
                cbxidseleccionado.addItem(idPaciente+" "+apellido+" "+nombre);
            }
        }
        catch (SQLException e)
        {
            JOptionPane.showMessageDialog(this,"Error al conectarse con la base de datos"+e.getMessage());
        }
    }
    
    private void GuardarDatos() //método
    {
        int presion_dias = 0;
        int presion_sis = 0;
        double temperatura_corporal = 0;
        double saturacion_oxigeno = 0;
        int frecuencia_respiratoria = 0;
        //Extrayendo la ID del paciente
        String idSeleccionado1 = cbxidseleccionado.getSelectedItem().toString(); //transformando a String
        String idSeleccionado2 = idSeleccionado1.replaceAll("[^0-9]","");  //removiendo números
        int idPaciente = Integer.parseInt(idSeleccionado2);
        //intento de parseo (evitar cerrar el programa al fallar)
        try
        {
            presion_dias = Integer.parseInt(txtpresiondiastolica.getText().trim());
            presion_sis = Integer.parseInt(txtpresionsistolica.getText().trim());
            temperatura_corporal = Double.parseDouble(txttemperaturacorporal.getText().trim());
            saturacion_oxigeno = Double.parseDouble(txtsaturacionoxigeno.getText().trim());
            frecuencia_respiratoria = Integer.parseInt(txtfrecuenciarespiratoria.getText().trim());
        }
        catch (NumberFormatException e)
        {
           JOptionPane.showMessageDialog(this,"Los valores ingresados no son válidos: ");
        }
        String sql = "Insert into signosvitales(id_paciente,presion_sistolica,presion_diastolica,temperatura_corporal,saturacion_oxigeno,frecuencia_respiratoria)values(?,?,?,?,?,?)";
        try
            (
                Connection conexion = Conexion.conectar();
                PreparedStatement pst = conexion.prepareStatement(sql)
            )
        {
            if (!txtfrecuenciarespiratoria.getText().isEmpty() && !txtpresiondiastolica.getText().isEmpty() && !txtpresionsistolica.getText().isEmpty() && !txtsaturacionoxigeno.getText().isEmpty() && !txttemperaturacorporal.getText().isEmpty())
            {
                pst.setInt(1, idPaciente);
                pst.setInt(2, presion_sis);
                pst.setInt(3, presion_dias);
                pst.setDouble(4, temperatura_corporal);
                pst.setDouble(5, saturacion_oxigeno);
                pst.setInt(6, frecuencia_respiratoria);
                int FilasAfectadas = pst.executeUpdate();
                if (FilasAfectadas > 0)
                {
                    JOptionPane.showMessageDialog(this,"Signos vitales del paciente guardados correctamente");
                }
                else
                {
                    JOptionPane.showMessageDialog(this,"Error al guardas los signos vitales",null,JOptionPane.ERROR_MESSAGE);
                }
            }
            else
            {
                JOptionPane.showMessageDialog(this,"Algunos campos están vacíos, por favor, rellena",null,JOptionPane.WARNING_MESSAGE);
            }
        }
        catch (SQLException e)
        {
            JOptionPane.showMessageDialog(this,"Error al conectar con la base de datos: "+e.getMessage());
        }
    }
    
    private void limpiar()
    {
        txtfrecuenciarespiratoria.setText("");
        txtpresiondiastolica.setText("");
        txtpresionsistolica.setText("");
        txtsaturacionoxigeno.setText("");
        txttemperaturacorporal.setText("");
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        cbxidseleccionado = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtpresionsistolica = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtpresiondiastolica = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txttemperaturacorporal = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        txtsaturacionoxigeno = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        txtfrecuenciarespiratoria = new javax.swing.JTextField();
        btnguardar = new javax.swing.JButton();
        btnlimpiar = new javax.swing.JButton();
        btnsalir = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setText("Seleccionar paciente");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 110, -1, -1));

        jPanel2.add(cbxidseleccionado, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 140, 175, -1));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setText("Presión arterial");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 170, 175, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel4.setText("Presión sistolica");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 200, -1, -1));
        jPanel2.add(txtpresionsistolica, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 230, 175, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel5.setText("Presión diastólica");
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 260, -1, -1));
        jPanel2.add(txtpresiondiastolica, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 290, 175, -1));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel6.setText("Temperatura corporal");
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 320, -1, -1));
        jPanel2.add(txttemperaturacorporal, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 350, 175, -1));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel7.setText("Exámenes respiratorios");
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 380, -1, -1));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel8.setText("Saturación de oxígeno");
        jPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 410, -1, -1));
        jPanel2.add(txtsaturacionoxigeno, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 440, 175, -1));

        jLabel9.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel9.setText("Frecuencia respiratoria");
        jPanel2.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 470, -1, -1));
        jPanel2.add(txtfrecuenciarespiratoria, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 500, 175, -1));

        btnguardar.setBackground(new java.awt.Color(0, 102, 255));
        btnguardar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnguardar.setForeground(new java.awt.Color(255, 255, 255));
        btnguardar.setText("Guardar");
        btnguardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnguardarActionPerformed(evt);
            }
        });
        jPanel2.add(btnguardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 530, 120, -1));

        btnlimpiar.setBackground(new java.awt.Color(0, 102, 255));
        btnlimpiar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnlimpiar.setForeground(new java.awt.Color(255, 255, 255));
        btnlimpiar.setText("Limpiar");
        btnlimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnlimpiarActionPerformed(evt);
            }
        });
        jPanel2.add(btnlimpiar, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 530, 120, -1));

        btnsalir.setBackground(new java.awt.Color(0, 102, 255));
        btnsalir.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnsalir.setForeground(new java.awt.Color(255, 255, 255));
        btnsalir.setText("Salir");
        btnsalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsalirActionPerformed(evt);
            }
        });
        jPanel2.add(btnsalir, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 530, 120, -1));

        jPanel1.setBackground(new java.awt.Color(0, 102, 255));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("REGISTRO DE SIGNOS VITALES");

        jPanel3.setBackground(new java.awt.Color(0, 91, 229));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 56, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(33, 33, 33))
        );

        jPanel2.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 430, 100));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 572, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnguardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnguardarActionPerformed
        // Guardar:
        GuardarDatos();
    }//GEN-LAST:event_btnguardarActionPerformed

    private void btnsalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsalirActionPerformed
        // Salir:
        new Frmlogin().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnsalirActionPerformed

    private void btnlimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnlimpiarActionPerformed
        // Limpiar:
        limpiar();
    }//GEN-LAST:event_btnlimpiarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Registro_de_signos_vitales.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Registro_de_signos_vitales.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Registro_de_signos_vitales.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Registro_de_signos_vitales.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Registro_de_signos_vitales().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnguardar;
    private javax.swing.JButton btnlimpiar;
    private javax.swing.JButton btnsalir;
    private javax.swing.JComboBox<String> cbxidseleccionado;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JTextField txtfrecuenciarespiratoria;
    private javax.swing.JTextField txtpresiondiastolica;
    private javax.swing.JTextField txtpresionsistolica;
    private javax.swing.JTextField txtsaturacionoxigeno;
    private javax.swing.JTextField txttemperaturacorporal;
    // End of variables declaration//GEN-END:variables
}
