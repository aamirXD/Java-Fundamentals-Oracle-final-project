package dominio;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class Práctica_00
{
        // Programa realizado por Johan Aamir Valentin Garcia 20/03/2025
        //conexión con la base de datos
        public static final String DB_URL= "jdbc:mysql://localhost:3306/Clinicaiberoamericana";
        public static final String DB_USER= "root";
        public static final String DB_PASS= "";
        //método conectar
        public static Connection conectar() //método conectar
        {
            Connection conexion= null;
            try
            {
                Class .forName("com.mysql.cj.jdbc.Driver");
                conexion=DriverManager.getConnection(DB_URL,DB_USER,DB_PASS);
                System.out.println("Conexión exitosa con la base de datos.");
            }
            catch (ClassNotFoundException e)
            {
                JOptionPane.showInternalMessageDialog(null,"No se encontró el Driver."+e);
                e.printStackTrace();
            }
            catch (SQLException e)
            {
                JOptionPane.showMessageDialog(null,"Error al intentar conectar con la base de datos."+e);
                e.printStackTrace();
            }
            return conexion;
            }
            public static void cerrarconexion(Connection conexion) //método que cierra la conexión
            {
                try
                {
                    if(conexion!= null && conexion.isClosed())
                    {
                        conexion.close();
                        JOptionPane.showMessageDialog(null,"Conexión cerrada con éxito");
                    }
                }
                catch (Exception e)
                {
                    JOptionPane.showMessageDialog(null,"Error al cerrar la conexión");
                    e.printStackTrace();
                }  
            }  
            public static void main(String[] args) //método main que ejecutará todo 
            {
                Connection con=conectar();
                cerrarconexion(con);
            }
        }