package dominio;
import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;
//clase Conexion
public class Conexion
{
    // Programa realizado por Johan Aamir Valentin Garcia 20/03/2025
        //conexión con la base de datos
        public static final String DB_URL= "jdbc:mysql://localhost:3306/Clinicaiberoamericana";
        public static final String DB_USER= "root";
        public static final String DB_PASS= "";
        //método conectar
        public static Connection conectar() //método conectar
        {
            Connection conexion= null;
            try
            {
                Class .forName("com.mysql.cj.jdbc.Driver");
                conexion=DriverManager.getConnection(DB_URL,DB_USER,DB_PASS);
                System.out.println("Conexión exitosa con la base de datos.");
            }
            catch (ClassNotFoundException e)
            {
                JOptionPane.showInternalMessageDialog(null,"No se encontró el Driver."+e);
                e.printStackTrace();
            }
            catch (SQLException e)
            {  
                JOptionPane.showMessageDialog(null,"Error al intentar conectar con la base de datos."+e);
                e.printStackTrace();
                try
                {
                    crearBaseYTablas();
                    conexion = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
                    System.out.println("Conexión exitosa con la base de datos después de crearla.");
                }
                catch (SQLException ex)
                {   
                    JOptionPane.showMessageDialog(null,"Error al crear la base de datos: "+ex.getMessage());
                }
            }
            return conexion;
            }
            public static void cerrarconexion(Connection conexion) //método que cierra la conexión
            {
                try
                {
                    if(conexion!= null && conexion.isClosed())
                    {
                        conexion.close();
                        JOptionPane.showMessageDialog(null,"Conexión cerrada con éxito");
                    }
                }
                catch (Exception e)
                {
                    JOptionPane.showMessageDialog(null,"Error al cerrar la conexión");
                    e.printStackTrace();
                }  
            }  
            
            public static void crearBaseYTablas() 
            {
                try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/", DB_USER, DB_PASS);
                Statement stmt = con.createStatement())
                {
                    stmt.executeUpdate("CREATE DATABASE IF NOT EXISTS Clinicaiberoamericana");
                    stmt.execute("USE Clinicaiberoamericana");

                    // Aquí pegas todas tus sentencias CREATE TABLE...
                    stmt.executeUpdate("CREATE TABLE IF NOT EXISTS Usuarios ("
                        + "id_usuario INT AUTO_INCREMENT PRIMARY KEY,"
                        + "nombre VARCHAR(100) NOT NULL,"
                        + "correo VARCHAR(100) UNIQUE NOT NULL,"
                        + "contraseña VARCHAR(255) NOT NULL,"
                        + "rol ENUM('Administrador', 'Doctor','Enfermero','Recepcionista') DEFAULT 'Administrador'");

                    stmt.executeUpdate("CREATE TABLE IF NOT EXISTS Especialidades ("
                        + "id_especialidad INT AUTO_INCREMENT PRIMARY KEY,"
                        + "nombre VARCHAR(100) UNIQUE NOT NULL)");

                    stmt.executeUpdate("CREATE TABLE IF NOT EXISTS Doctores ("
                        + "id_doctor INT AUTO_INCREMENT PRIMARY KEY,"
                        + "id_usuario INT NOT NULL,"
                        + "id_especialidad INT NOT NULL,"
                        + "numero_colegiado VARCHAR(50),"
                        + "biografia TEXT,"
                        + "FOREIGN KEY (id_usuario) REFERENCES Usuarios(id_usuario) ON DELETE CASCADE,"
                        + "FOREIGN KEY (id_especialidad) REFERENCES Especialidades(id_especialidad) ON DELETE CASCADE)");
                    // Tablas añadidas a partir de aquí:
                    stmt.executeUpdate("CREATE TABLE IF NOT EXISTS Pacientes ("
                        + "id_paciente INT AUTO_INCREMENT PRIMARY KEY,"
                        + "dni VARCHAR(15) UNIQUE NOT NULL,"
                        + "nombre VARCHAR(100) NOT NULL,"
                        + "apellido VARCHAR(100) NOT NULL,"
                        + "fecha_nacimiento DATE NOT NULL,"
                        + "genero ENUM('Masculino', 'Femenino', 'Otro') NOT NULL,"
                        + "direccion TEXT,"
                        + "telefono VARCHAR(20),"
                        + "email VARCHAR(100) UNIQUE)");

                    stmt.executeUpdate("CREATE TABLE IF NOT EXISTS HistoriasClinicas ("
                        + "id_historia INT AUTO_INCREMENT PRIMARY KEY,"
                        + "id_paciente INT NOT NULL,"
                        + "fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,"
                        + "antecedentes TEXT,"
                        + "diagnostico TEXT,"
                        + "tratamiento TEXT,"
                        + "FOREIGN KEY (id_paciente) REFERENCES Pacientes(id_paciente) ON DELETE CASCADE)");

                    stmt.executeUpdate("CREATE TABLE IF NOT EXISTS Consultas ("
                        + "id_consulta INT AUTO_INCREMENT PRIMARY KEY,"
                        + "id_paciente INT NOT NULL,"
                        + "id_usuario INT NOT NULL,"
                        + "fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,"
                        + "motivo TEXT,"
                        + "observaciones TEXT,"
                        + "FOREIGN KEY (id_paciente) REFERENCES Pacientes(id_paciente) ON DELETE CASCADE,"
                        + "FOREIGN KEY (id_usuario) REFERENCES Usuarios(id_usuario) ON DELETE CASCADE)");

                    stmt.executeUpdate("CREATE TABLE IF NOT EXISTS AnalisisMedicos ("
                        + "id_analisis INT AUTO_INCREMENT PRIMARY KEY,"
                        + "id_paciente INT NOT NULL,"
                        + "tipo_analisis VARCHAR(100) NOT NULL,"
                        + "resultado TEXT,"
                        + "fecha_realizacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,"
                        + "FOREIGN KEY (id_paciente) REFERENCES Pacientes(id_paciente) ON DELETE CASCADE)");

                    stmt.executeUpdate("CREATE TABLE IF NOT EXISTS MetodosPago ("
                        + "id_metodo_pago INT AUTO_INCREMENT PRIMARY KEY,"
                        + "nombre VARCHAR(50) UNIQUE NOT NULL)");

                    stmt.executeUpdate("CREATE TABLE IF NOT EXISTS Facturacion ("
                        + "id_factura INT AUTO_INCREMENT PRIMARY KEY,"
                        + "id_paciente INT NOT NULL,"
                        + "fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,"
                        + "detalle TEXT,"
                        + "monto DECIMAL(10,2) NOT NULL,"
                        + "estado ENUM('Pendiente', 'Pagado') DEFAULT 'Pendiente',"
                        + "FOREIGN KEY (id_paciente) REFERENCES Pacientes(id_paciente) ON DELETE CASCADE)");

                    stmt.executeUpdate("CREATE TABLE IF NOT EXISTS Pagos ("
                        + "id_pago INT AUTO_INCREMENT PRIMARY KEY,"
                        + "id_factura INT NOT NULL,"
                        + "id_metodo_pago INT NOT NULL,"
                        + "monto DECIMAL(10,2) NOT NULL,"
                        + "fecha_pago TIMESTAMP DEFAULT CURRENT_TIMESTAMP,"
                        + "FOREIGN KEY (id_factura) REFERENCES Facturacion(id_factura) ON DELETE CASCADE,"
                        + "FOREIGN KEY (id_metodo_pago) REFERENCES MetodosPago(id_metodo_pago) ON DELETE CASCADE)");

                    stmt.executeUpdate("CREATE TABLE IF NOT EXISTS Evaluaciones ("
                        + "id_evaluacion INT AUTO_INCREMENT PRIMARY KEY,"
                        + "id_paciente INT NOT NULL,"
                        + "id_doctor INT NOT NULL,"
                        + "fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,"
                        + "calificacion INT CHECK (calificacion >= 1 AND calificacion <= 5),"
                        + "comentario TEXT,"
                        + "FOREIGN KEY (id_paciente) REFERENCES Pacientes(id_paciente) ON DELETE CASCADE,"
                        + "FOREIGN KEY (id_doctor) REFERENCES Doctores(id_doctor) ON DELETE CASCADE)");

                    stmt.executeUpdate("CREATE TABLE IF NOT EXISTS Citas ("
                        + "id_cita INT AUTO_INCREMENT PRIMARY KEY,"
                        + "id_paciente INT NOT NULL,"
                        + "id_doctor INT NOT NULL,"
                        + "fecha_cita DATETIME NOT NULL,"
                        + "estado ENUM('Pendiente', 'Confirmada', 'Cancelada') DEFAULT 'Pendiente',"
                        + "FOREIGN KEY (id_paciente) REFERENCES Pacientes(id_paciente) ON DELETE CASCADE,"
                        + "FOREIGN KEY (id_doctor) REFERENCES Doctores(id_doctor) ON DELETE CASCADE)");
                    
                    stmt.executeUpdate("CREATE TABLE IF NOT EXISTS signosvitales ("
                        + "id_signosvitales INT AUTO_INCREMENT PRIMARY KEY,"
                        + "id_paciente INT NOT NULL,"
                        + "presion_sistolica INT NOT NULL,"
                        + "presion_diastolica INT NOT NULL,"
                        + "temperatura_corporal DOUBLE NOT NULL,"
                        + "saturacion_oxigeno DOUBLE NOT NULL,"
                        + "frecuencia_respiratoria INT NOT NULL,"
                        + "FOREIGN KEY (id_paciente) REFERENCES pacientes(id_paciente) ON DELETE CASCADE)");

                        System.out.println("Base de datos y tablas creadas correctamente.");
                } 
                catch (SQLException e) 
                {
                    JOptionPane.showMessageDialog(null, "Error al crear la base de datos o tablas. " + e.getMessage());
                    e.printStackTrace();
                }   
            }
            public static void main(String[] args) //método main que ejecutará todo 
            {
                Connection con=conectar();
                cerrarconexion(con);
            }
}
